from .core import AppIcon
from .core import NotificationManager
import toga
