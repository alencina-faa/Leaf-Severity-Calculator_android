﻿from .core import UriOutputStream
from .core import UriTextOutputStream
