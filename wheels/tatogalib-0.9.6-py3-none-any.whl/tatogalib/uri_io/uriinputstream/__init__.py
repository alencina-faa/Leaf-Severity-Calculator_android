from .core import UriInputStream
from .core import UriTextInputStream
