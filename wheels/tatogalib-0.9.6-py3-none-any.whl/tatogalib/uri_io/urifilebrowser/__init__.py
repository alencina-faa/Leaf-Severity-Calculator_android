from .core import UriFileBrowser
